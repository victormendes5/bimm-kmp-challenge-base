package com.bimm.takehomeassignmnent.data

object NetworkConfig {
    const val SakeShopEndpoint =
        "https://private-4ab845-test11663.apiary-mock.com/sakeshop"
}